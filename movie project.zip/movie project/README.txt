first project of Udacity full stack developer nanodegree
Diego J. Argibay
1/30/2018

file fresh_tomatoes.py gotten from Git respository provided by Udacity