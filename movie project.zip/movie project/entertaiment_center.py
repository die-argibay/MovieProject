import media
import fresh_tomatoes

#define the selected movies

burlesque = media.Movie("Burlesque",
                        "A story about Christina Aguilera and Cher",
                        "http://www.impawards.com/2010/posters/burlesque.jpg",
                        "https://www.youtube.com/watch?v=vyML3Kd5wXs")


lion_king = media.Movie("The Lion King",
                        "A story about a Lion and the kingdom",
                        "https://upload.wikimedia.org/wikipedia/en/thumb/3/3d/The_Lion_King_poster.jpg/220px-The_Lion_King_poster.jpg",
                        "https://www.youtube.com/watch?v=GibiNy4d4gc")

avatar = media.Movie("Avatar",
                     "A story about a blue animals and another world",
                     "https://s.yimg.com/ny/api/res/1.2/.hvogCDvuDOc3qn8Q.wyJA--/YXBwaWQ9aGlnaGxhbmRlcjtzbT0xO3c9ODAwO2lsPXBsYW5l/http://media.zenfs.com/en_US/News/US-AFPRelax/avatar_poster_2.e903e101639.original.jpg",
                     "https://www.youtube.com/watch?v=VhBscl6SbnY")
                     
                     
#create array to save the movies
movies = [burlesque, lion_king, avatar]
#call fresh_tomatoes and the function to open the movie website
fresh_tomatoes.open_movies_page(movies)
                                                


